This utility can be used for extracting and anonymizing specific customer data created in eGain application.

Steps to run this utility:

1. Copy the utility on Services Server (preferably inside '<egain_home>\Utilities' folder)

2. Provide required parameters in 'input.properties' file.

3. Provide information of the customer (for whom the utility needs to be executed) in a json file and keep all such files in utility input folder. A sample json format file is present in '/sample' folder.

4. For Windows system, open command prompt and run following command:

		GdprUtility.bat -i "<input_json_location>" -o "<output_location>"
		
	e.g. GdprUtility.bat -i "C:\eGain\Utilities\GDPR_Utility\input" -o "C:\eGain\Utilities\GDPR_Utility\output"
	
5. After running the utility, check '<FS_HOME_DIR>\eService\logs\eg_log_<hostname>_GDPRUtility.log' for details about last execution of utility. Here FS_HOME_DIR is File Server home directory or NAS path.

6. In case of ProfileOut, check 'output' folder for the output files created by utility.