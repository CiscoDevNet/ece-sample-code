/*
 * This file contains the environment information that will be used for all examples. 
 * Before attempting to execute any of the examples you should modify this file accordingly 
 * and validate your Proxy Settings if required.
 */
var CorsHost = "system";

$(document).on('pageshow', '#HomePage', function () {
    if ($.cookie('corsHost') === undefined) {
        $.cookie('corsHost',CorsHost);  
    } 
    $('#CorsHost').val($.cookie('corsHost'));
    $('#CorsHost').on('change',function() {
        $.cookie('corsHost',$('#CorsHost').val());
    });    
});

