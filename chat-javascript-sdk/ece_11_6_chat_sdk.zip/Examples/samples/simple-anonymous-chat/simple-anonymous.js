/* Create a new instance of the eGainLibrarySettings Object */
var myLibrarySettings = new eGainLibrarySettings();
myLibrarySettings.CORSHost = $.cookie('corsHost');
myLibrarySettings.IsDevelopmentModeOn = false;
myLibrarySettings.eGainContextPath = "./";
/* Next create a new instance of the eGainLibrary */
/* passing in the settings you have just created. */
var myLibrary = new eGainLibrary(myLibrarySettings);
/* Now create an instance of the Chat Object */
var myChat = new myLibrary.Chat();
/* Next get the event handlers for chat. It is mandatory to provide definition for the mandatory event handlers before initializing chat */
var myEventHandlers = myChat.GetEventHandlers();

$(document).on('pageshow', "#SimpleAnonymousChat", function () {
    $('.CurrentCorsHost').each(function (index, value) {
        $(value).html($.cookie('corsHost'));
    });
});

$(document).on('pageinit', '#SimpleAnonymousChat', function () {
	var agentName = "";
    $("#SendMessage").on('click', function () {
        myChat.SendMessageToAgent($('#ChatInputMessages').val());
        $('#TransScript').append("<br />You: " + $('#ChatInputMessages').val());
        $('#ChatInputMessages').val("");
    });
	var file = "";
	$("#SendAttachment").on('click', function (evt) {
		var fileInput = document.getElementById("attachment");
		if(fileInput.files.length>0){
			file = fileInput.files[0];
			myChat.SendCustomerAttachmentNotification(fileInput.files,"Customer");
		};
        
    });

	$("#attachment").on("change", function(event){
		var fileInput = document.getElementById("attachment");
		if(fileInput.files.length>0){
			file = event.target.files[0];
		}
	});

    $("#ChatInputMessages").on('keypress', function(evt) {
        if (evt.keyCode === 13)
        {
            myChat.SendMessageToAgent($('#ChatInputMessages').val());
            $('#TransScript').append("<br />You: " + $('#ChatInputMessages').val());
            $('#ChatInputMessages').val("");
        }
    });

    $("#EndChat").on('click', function () {
        myChat.End();
        $.mobile.changePage("#SimpleAnonymousChatPostChatScreen");
    });


    $('#StartAnonymousChatButton').on('click', function () {
        /* Example browser alert when chat is connected */
        myEventHandlers.OnConnectSuccess = function () {
            alert('Chat Started!');
        };

		myEventHandlers.OnAgentJoined = function (agentJoinedEventArgs) {
            agentName = agentJoinedEventArgs.AgentName;
        };

        /* Example browser alert when there is a connection failure */
        myEventHandlers.OnConnectionFailure = function () {
            alert('Oops! Something went wrong');
        };
		
		/* Example browser alert when there is an error during chat */
        myEventHandlers.OnErrorOccurred = function () {
            alert('Oops! Something went wrong');
        };

        /* Example output of agent messages to a DIV named TransScript with jQuery */
        myEventHandlers.OnAgentMessageReceived = function (agentMessageReceivedEventArgs) {
            $('#TransScript').append("<br />Agent: " + agentMessageReceivedEventArgs.Message);
        };
        /* Example output of system messages to the same DIV */
        myEventHandlers.OnSystemMessageReceived = function (systemMessageReceivedEventArgs) {
            $('#TransScript').append("<br />" + systemMessageReceivedEventArgs.Message);
        };
        /* Example browser alert when agents are not available */
        myEventHandlers.OnAgentsNotAvailable = function (agentsNotAvailableEventArgs) {
            alert('Sorry no agents available');
        };
        /* Example browser alert when the chat is completed */
        myEventHandlers.OnConnectionComplete = function () {
            $.mobile.changePage("#SimpleAnonymousChatPostChatScreen")
        };
		/* Example of adding message in transcript when customer attachment invite is sent to server */
		myEventHandlers.OnCustomerAttachmentNotificationSent = function(customerAttachmentNotificationSentEventArgs){
			$('#TransScript').append("<br />" + "Waiting for agent to accept attachment");
		};
		/* Example of adding message in transcript when customer attachment invite is sent to server */
		myEventHandlers.OnAttachmentAcceptedByAgent = function(attachmentAcceptedByAgentEventArgs){
			file.uniqueFileId = attachmentAcceptedByAgentEventArgs.uniqueFileId;
			myChat.UploadAttachment(file,attachmentAcceptedByAgentEventArgs.agentName);
		};

        /* Now call the Chat initialization method with your entry point and callbacks */
        myChat.Initialize($('#ChatEntryPointId').val(),'en', 'US', myEventHandlers, 'aqua', 'v11');
		/*Create an anonymous customer and set the customer for chat*/
		var customerObject =  new myLibrary.Datatype.CustomerObject();
        customerObject.SetPrimaryKey(customerObject.PrimaryKeyParams.PRIMARY_KEY_EMAIL, "anonymous@egain.com");
		myLibrary.SetCustomer(customerObject);
		/* Start chat */
        myChat.Start();

        $.mobile.changePage("#SimpleAnonymousChatInteractionScreen");
    });
});